package com.ey.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class MapConfiguration {

   @Bean
   public Map<String, AtomicLong> getMap(){
      Map<String, AtomicLong> map = new HashMap<>();
      return map;      
   }
}