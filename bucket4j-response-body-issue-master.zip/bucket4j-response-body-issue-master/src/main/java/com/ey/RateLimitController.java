package com.ey;




import com.sun.istack.internal.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;


@RestController
public class RateLimitController {



	@PostMapping(value = "/api/v1/search")
	public ResponseEntity<Map<String,String>> search(@RequestHeader HttpHeaders headers, HttpServletResponse httpServletResponse) {
		Map<String,String> responseMap = new HashMap<>();
		responseMap.put("UserMailId",headers.get("mailid").get(0));
		responseMap.put("Remaining Search Request Left",httpServletResponse.getHeader("X-Rate-Limit-Remaining"));
		return ResponseEntity.ok(responseMap);
	}


	
}
