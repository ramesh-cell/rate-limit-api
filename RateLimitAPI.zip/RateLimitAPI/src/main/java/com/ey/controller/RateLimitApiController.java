package com.ey.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@RestController
public class RateLimitApiController {

    @Autowired
    private Map<String, AtomicLong> getMap;



    @PostMapping("api/v1/search")
    public ResponseEntity<String> countSearch(@RequestParam("mailid") String emailId){
            if (!getMap.containsKey(emailId)){
                getMap.put(emailId,new AtomicLong(0));
            }
        if(getMap.get(emailId).longValue()==5){
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).body("You have Exhausted your API Search Quota");
        }
        getMap.get(emailId).getAndIncrement();

        return ResponseEntity.ok("Welcome to EY Search Application "+getMap.get(emailId).get());

    }
}
